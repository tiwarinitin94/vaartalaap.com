<?php
//very important ! do not change
    define('HASH_KEY','SAPANOseBHareNainaSargam9211#includestdiomain');
	//for password
    define('HASH_KEY_PSWD','Sargam9211#includestdiomainSAPANOseBHareNaina');

?>