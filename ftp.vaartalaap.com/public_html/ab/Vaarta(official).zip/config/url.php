<?php
define('URL','http://localhost/Vaarta(official)/');

define('LIBS','libs/');
?>