<?php
      class about_model extends Models{
	  public function __construct(){
		   parent::__construct();
                 
		   }
	

	public function submit_bug(){
		echo "Submit Bug";
	}
	 
	  }
?>