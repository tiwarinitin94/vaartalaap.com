<?php
       class error_model extends Models{
       
           public function __construct(){
		   parent::__construct();
                 
		   }
       
       }



?>