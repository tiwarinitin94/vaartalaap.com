<?php
      class post_user_model extends Models{
	  public function __construct(){
		   parent::__construct();
                 
		   }
	public function profile_user(){
		
	}
	
	 
	  }
?>