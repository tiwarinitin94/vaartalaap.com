<?php
      class privacy_model extends Models{
	  public function __construct(){
		   parent::__construct();
                 
		   }
	

	 
	  }
?>