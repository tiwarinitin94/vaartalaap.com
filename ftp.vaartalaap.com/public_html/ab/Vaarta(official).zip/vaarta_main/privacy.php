<?php
class privacy extends Controller{
      
		  function __construct(){
		 
		    parent::__construct();
			
		 
		
}

function Index(){
		 $this->view->render('privacy/index');
		
}



}
?>