
<div class="content" style="">

 <div class="modal-content1" style="margin:100px auto;padding: 40px; width:400px; box-shadow:.0px .1px .1px 1px #fefefef;border:.1px solid #fbfbfb; ">
     
     
          <center>
	        
		<label style="padding:10px;font-family:helvetica;font-size:15px;">If already a member sign in</label>
		   <form action="<?php echo URL;?>login/run" id="logged_in" method="POST" style="padding:20px;">
		    <input type="text" name="user_login"  autofocus placeholder="Username or em@il Id"/><p/>
			  <span><input type="password" name="password_login"  placeholder="Password"/><p/></span>
			  <input type="submit" name="login" value="Sign In" style="width:265px;border-radius:0px;box-shadow:none;border:.5px solid #fff;background-color:rgb(20,120,220);color:#fff; padding:8px;"/>
		   </form>
		   <a href="forgot.php" style="text-decoration:none;font-size:10px;margin-left:20px;">Forgot password ?</a>
		  </center>
             
     </div>
		
	

</div>
