
<div class="content"  >
<div id="wrapper">
 <div class="panel-group" style="margin-top:100px;">
    <div class="panel panel-default">
      <div class="panel-heading">Policy</div>
      <div class="panel-body">Hello all there, Vaartalaap is a social site, that is based on "Conversation". Conversation not just from writing something, but also by creating something that express what you want to say. So for that we collect the data, most of data we collect from our registered user, are like images and there thoughts about their own life, and who they follow, what they want to do. <br> <br> Basically we try to retrieve the creative side of our users. All data of yours is yours only. You can have your all data whenever you want. There are privacy setting by which you can limit the audience or you can share them publicly. Thank you </div>
    </div>

	 <div class="panel panel-info">
      <div class="panel-heading">Privacy</div>
      <div class="panel-body">We have privacy in post sharing, user will be able to share the data only amount of people he/she wants to. And the creative information that user puts in his/her profile, user can also limit the audience to see that. Basically our work is to provide the security that our user want, and we will do our best to do that.  </div>
    </div>
	
    <div class="panel panel-primary">
      <div class="panel-heading">Trekker's</div>
      <div class="panel-body">Trekker's is our social travel app, which is for creating a social connection between travellers around the world. In which you can share all the picture of the places you have been, and also this supports our PM's Incredible India campaign, in which our PM want us to show the India to the world. In short this will also help tourism.  </div>
    </div>

    <div class="panel panel-success">
      <div class="panel-heading">Data of Vaartalaap</div>
      <div class="panel-body">Data of vaartalaap will be in fully control of registered users only. If you have shared thatdata you have right to remove it, we are developing a way to control the data even if it is shared by other people. The person who has shared that data originally will have full control to remove it or keep it. </div>
    </div>

    <div class="panel panel-info">
      <div class="panel-heading">Data of Trekker's</div>
      <div class="panel-body">Trekker's usually collects only travelling images, and no ther personal data of a person. And one contact number if user want it. All the other images and all will be in control of registered user. We also use email id, so that we could send account related information on that email. And there is no other personal information you need to provide.  </div>
    </div>

    <div class="panel panel-warning">
      <div class="panel-heading">Cookies</div>
      <div class="panel-body">There are no cookies data that our website or app collects. If in future we will do that we will let everyone know. </div>
    </div>

    <div class="panel panel-danger">
      <div class="panel-heading">Location data</div>
      <div class="panel-body">We use location data in Trekker's only for the comfort of user, so that user will automatically fill the name of the place he is taking photo. Other wise there is also an option to put the location manuallly. it depends on the user which he/she prefers. </div>
    </div>
	  <div class="panel panel-info">
      <div class="panel-heading">Image & Video data</div>
      <div class="panel-body">All the image data will belong to registered user, mostly we want our user to express with their creative mind, and media(Image and videos) help them to do it creatively. But user will have full control to delete or keep their data on the site. Thank you </div>
    </div>
	
  </div>
  </div>
</div>
