<?php
      class settings_model extends Models{
	  public function __construct(){
		   parent::__construct();
                 
		   }
	public function profile_user(){
		
	}
	
	
	public function update_data($data){
		$user=Session::get('user');
		$id=Session::get('id');
		$update=$_POST['data'];
		
		if($data=='q'){
			 $update=$this->db->update("info_users","fav_quote='$update'", "user_id='$id'");
		}elseif($data=='h'){
			 $update=$this->db->update("info_users","hobby='$update'","user_id='$id'");
	}elseif($data=='w'){
		 $update=$this->db->update("info_users","about_you='$update'","user_id='$id'");
		                 
	}elseif($data='said'){
		$update=$this->db->update("info_users","said_by='$update'","user_id='$id'");
	}else{
		echo "Go to hell ";
	}
	  }
	  
	public function update_data_of_info($data){
		$user=Session::get('user');
		$id=Session::get('id');
		$update=$_POST['data'];
		$update2=$_POST['data_sir'];
		echo $data;
	if($data=='f_n'){
			 $update=$this->db->update("myusers","first_name='$update'", "id='$id'");
		  $update=$this->db->update("myusers","last_name='$update2'", "id='$id'");
			 
		}elseif($data=='tag'){
			 $update=$this->db->update("myusers","bio='$update'","id='$id'");
	}elseif($data=='ct'){
		 $update=$this->db->update("myusers","country='$update'","id='$id'");
		                 
	}else{
		echo "Go to hell ";
	}
	  }
	  
	  
public function update__profile_image($theData){
	$username=Session::get('user');
		$id=Session::get('id');
		   if(isset($_FILES['profilepic'])){
			 
     if (((@$_FILES["profilepic"]["type"]=="image/jpeg") || (@$_FILES["profilepic"]["type"]=="image/png") || (@$_FILES["profilepic"]["type"]=="image/gif")||(@$_FILES["profilepic"]["type"]=="image/jpg")||(@$_FILES["profilepic"]["type"]=="image/png"))&&(@$_FILES["profilepic"]["size"] < 1048576)){
	          $chars="abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
			  $rand_dir_name = substr(str_shuffle($chars), 0, 15);
			  if(!mkdir("./public/userdata/profile_pics/$rand_dir_name")){
			     echo "Cannot make directory";
			  }
			 
                    
			  if (file_exists("./public/userdata/profile_pics/$rand_dir_name/".@$_FILES["profilepic"]["name"])){
                 echo @$_FILES["profilepic"]["name"]." Already exists";
   }
    else
   {
      $temp = explode(".", $_FILES["profilepic"]["name"]);
       $newfilename = round(microtime(true)) . '.' . end($temp);
    move_uploaded_file(@$_FILES["profilepic"]["tmp_name"],"./public/userdata/profile_pics/$rand_dir_name/".$newfilename);
	
     $profile_pic_name = @$newfilename;
    $update = $this->db->update("myusers","profile_pic='$rand_dir_name/$profile_pic_name'","username='$username'");
    $date_added =  date('l\, F jS\, Y ');// Date on added
    $added_by = $username;
    $user_posted_to = $username;
	 $insert=$this->db->insert("posts","('','$username has changed profile pic','$date_added','$added_by','$user_posted_to','$rand_dir_name/$profile_pic_name','')");  
     
	 echo $rand_dir_name.'/'.$profile_pic_name;
	  }
  }
  else
  {
      echo "Invailid File! Your image must be no larger than 1MB and it must be either a .jpg, .jpeg, .png or .gif";
  }
   }else{
	   echo "hi";
   }
}

public function remove__profile_image($theData){	  
     $username=Session::get('user');
		 $update = $this->db->update("myusers","profile_pic=''","username='$username'");

	 }
public function check_relation(){
	$from=Session::get('user');
	$user_to= $_POST['data'];
	$select=$this->db->select('*','friend_requests',"user_from='$from'&& user_to='$user_to'");
	$select1=$this->db->select('*','friend_requests'," user_from='$user_to'&& user_to='$from'");
	if($select->rowCount()==1){
		echo $from;
	}elseif($select1->rowCount()==1){
		echo $user_to;
	}else{
		echo "";
	}
}
public function send_request(){
	$from=Session::get('user');
	$user_to= $_POST['data'];
	//	"SELECT* FROM friend_requests WHERE user_from='$username'&& user_to='$username1' or user_to='$username1'&& user_from='$username'"
	
	$insert=$this->db->insert("friend_requests","('','$user_to','$from')");  
     
	
}
public function cancel_request(){
	$from=Session::get('user');
	$user_to= $_POST['data'];
	//	"SELECT* FROM friend_requests WHERE user_from='$username'&& user_to='$username1' or user_to='$username1'&& user_from='$username'"
	
	$insert=$this->db->delete("friend_requests","user_from='$from' && user_to='$user_to' OR user_to='$from' && user_from='$user_to'");  
     
	
}

public function follow_the_user($idiot){
	$from=Session::get('user');
	$user_id="";
	
	if(isset($_POST['uid'])){
		$user_id= $_POST['uid'];
	$check=$this->db->select('*','myusers',"username='$user_id'");
	if($check->rowCount()==1){
		
		
	if($this->check_follow($user_id)){
		 echo "You already follow $user_id";
	}else{
  $insert=$this->db->insert("follow","('','$from','$user_id')");
    echo "You have followed $user_id";
	}
		
	}
	}elseif(isset($_POST['un_id'])){
		$user_id= $_POST['un_id'];
		
		$check=$this->db->select('*','myusers',"username='$user_id'");
	if($check->rowCount()==1){
	 $delete=$this->db->delete("follow","followed_to='$user_id' && followed_by='$from'");
	 echo "You have unfollowed $user_id";
	}else{
		
	}
		
	}
}

public function check_follow($user_id){
	$from=Session::get('user');
	$check2=$this->db->select("*","follow","followed_to='$user_id' && followed_by='$from'");
	if(isset($_POST['u_id_check'])){
		if($check2->rowCount()==1){
		echo "yes";
	}else{
		echo "";
	}
	}
	if($check2->rowCount()==1){
		return true;
	}else{
		return false;
	}
}	
	


	 
	  }
?>