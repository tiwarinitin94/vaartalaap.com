<?php 
define('DB_TYPE','mysql');
define('DB_HOST','localhost');
define('DB_NAME','vaartala_myusers');
define('DB_USER','vaartala_nt');
define('DB_PASS','#includestdiomain');



?>