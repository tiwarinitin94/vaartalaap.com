<?php
define('URL','http://vaartalaap.com/');

define('LIBS','libs/');
?>