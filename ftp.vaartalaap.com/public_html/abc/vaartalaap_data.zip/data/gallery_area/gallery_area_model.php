<?php
       class gallery_area_model extends Models{
       
           public function __construct(){
		   parent::__construct();
                 
		   }
       
       }



?>