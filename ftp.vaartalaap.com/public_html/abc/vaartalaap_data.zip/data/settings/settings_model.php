<?php
      class settings_model extends Models{
	  public function __construct(){
		   parent::__construct();
                 
		   }
	public function profile_user(){
		
	}
	
	
	


	 
	  }
?>