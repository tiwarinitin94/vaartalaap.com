function check_screen(){$(window).innerWidth()<=550?($(".modal-content1").css("width","100%"),$(".modal-content").css("width","100%"),$(".content").css("padding","0px"),$(".postForm1").css("width","100%"),$(".postForm1").css("margin","5px auto")):($(".modal-content1").css("width","600px"),$(".modal-content").css("width","600px"),$(".postForm1").css("margin","90px auto"),$(".postForm1").css("width","550px"),$(".content").css("padding","10px 20px 10px 20px"))} function go(e){alert(e)}function modal(){for(var e=[],t=0;t<arguments.length;++t)e[t]=arguments[t];var n=e[0];if(e[1]){e[1];$(".modal-content").css("margin","10px auto")}var o=document.getElementById("myModal2"),l=document.getElementById("mymodalc"),s=document.getElementById("close2");o.style.display="block",l.innerHTML=n,s?s.onclick=function(){(o=document.getElementById("myModal2")).style.display="none"}:(s=document.getElementById("close2")).onclick=function(){o.style.display="none"},window.onclick=function(e){e.target==o&&(o.style.display="none")}}function getCaret(e){if(e.selectionStart)return e.selectionStart;if(document.selection){e.focus();var t=document.selection.createRange();if(null==t)return 0;var n=e.createTextRange(),o=n.duplicate();return n.moveToBookmark(t.getBookmark()),o.setEndPoint("EndToStart",n),o.text.length}return 0}function showResult(e){$("#livesearch").html(e)}function send_request(e){$.post(url_vrt+"profile/send_request",{data:e},function(e){$("#add_user").html("Request Sent"),$("#vaarta_rel").append('<button onclick="cancel()" id="cr_cancel">Cancel Request</button>')})}function follow_user(e){jQuery.ajax({type:"POST",url:url_vrt+"profile/follow/slsfjshsfhdfhsdfhsohughreuhsvsgbskfhnjsdfhdajhadlfhadfoiwfsnvskvbjshdsijf",data:{uid:e},dataType:"text",success:function(e){$("#follow").html("Following")}})}function unfollow_user(e){jQuery.ajax({type:"POST",url:url_vrt+"profile/follow/slsfjshsfhdfhsdfhsohughreuhsvsgbskfhnjsdfhdajhadlfhadfoiwfsnvskvbjshdsijf",data:{un_id:e},dataType:"text",success:function(e){$("#follow").html("Follow")}})}function setTitle(e){document.title=e}$(document).ready(function(){check_screen(); $(window).resize(function(e){check_screen()});var e=document.getElementById("myModal"),t=document.getElementById("myBtn"),n=document.getElementById("close1");t&&(t.onclick=function(){e.style.display="block"}),n&&(n.onclick=function(){e.style.display="none"}),window.onmousemove= function(e){if(e.y>= $(document).height()-10){alert('you did hit the bottom!');}},window.onclick=function(t){t.target==e&&(e.style.display="none")},window.onbeforeunload=function(){alert("Are you sure?")};var o=0;$(window).scroll(function(e){var t=$(this).scrollTop();Math.abs(o-t)<=20||(t>o?($("#search_box")&&$("#search_box").hide(),$('#bottom_menu').hide()):($("#search_box")&&$("#search_box").show(),$('#bottom_menu').show()),o=t)}),$(".header20").hover(function(){$("#search_box").show()})});var url_vrt="http://vaartalaap.com/";


var user_logged="";
 var id_record = new Array(); var counter=0; var obj=new Array(); var obj_user=new Array();
 var the_new_crid="now"; var lastScrollTop = 0;	var lastScrollHeight=0;

 var img = document.createElement('img');

 
 function getchatsession(){
		$.post(url_vrt+"message/update_chat_session",function (o){
			
			
			  for(i=0;i<o.length;i++){
				alert(o[i]);
			  }
			},'json');
	
	
	}
function savechat(update_cid){
	$.post(url_vrt+"message/save_chat_session",{c_id:update_cid},function (o){
		//alert(o)
		});
	
}
$(document).ready(function(){

$('form').submit(function(){
      
});


	
  if(user_logged!=""){
   getchatsession();
  }

 $('#msg_chat').scroll(function(event){
		
		msgarea=document.getElementById("msg_chat");
		    var st = $(this).scrollTop();
		   if (st == msgarea.scrollHeight){
			   
			   setInterval(function(){  fetch_message($('#this_counter_for_cid').html(),'',$('#msg_chat')); }, 4500);
   
   }else if(st==lastScrollTop) {
	    if($('#this_counter_for_cr_id').html()!="Nothing"){
	   fetch_cid=$('#this_counter_for_cid').html();
         fetch_message(fetch_cid,the_new_crid,$('#msg_chat'));
   }else {
	  
	   }
   }
	 });
	

$(".msg_chat_class").submit(function(e){var i=$(".msg_chat_class").attr("rel");return current_cid="thissdlfhdgjhasbgadbgbdfdahgljadfhadjfhadjfhdfhdsajfhjdfhdljfhdlasfhldfjadjfafjadfj"+$("#this_counter_for_cid").html(),e.preventDefault(),$.ajax({url:i+"/"+current_cid,type:"POST",data:new FormData(this),contentType:!1,async:!1,cache:!1,processData:!1,success:function(e){fetch_message($("#this_counter_for_cid").html(),"",$('#msg_chat')),$("#msginput").val(""),$("#msginput_chat").val(""),document.getElementById("file_chat").value="",document.getElementById("file").value=""}})	
});
});
function chatRun(){var attrVal= $('#send_msg').attr("rel"); if(attrVal.trim()!=="no Message"){ savechat(attrVal); if($('.chatbox').css('display')=="none"){fetch_message(attrVal,"",$('#msg_chat'))} $('.chatbox').toggle(); $('#this_counter_for_cid').html(attrVal);}else{$('#msg_chat').html('<center style="color:#999; padding:20px;background:#fbfbfb; font-size:12px;">No Messages to show....</center>');$('.chatbox').toggle();}  }

function fetch_message(e,t,m_ele){new Image;"now"==t?(fetch_cr_id=$("#this_counter_for_cr_id").html(),$.post(url_vrt+"message/get_the_anonymous_activity_that_is_going_out_there",{the_new_crid:fetch_cr_id,cid:e},function(e){for($("#this_counter_for_cr_id").html(""),e.sort(function(e,i){return i.cr_id-e.cr_id}),i=0;i<e.length;i++)$("#this_counter_for_cr_id").html(e[e.length-1].cr_id),"Nothing"!=e[i].pics?(pic_sent=url_vrt+"public/userdata/data_pics/"+e[i].pics,img.src=pic_sent,img_wdth=img.width,img_height=img.height,img_wdth>200?(img__wdth=200,img_height=img_height/img_wdth*img__wdth):img__wdth=img_wdth,pic_sent='<img src="'+url_vrt+"public/userdata/data_pics/"+e[i].pics+'" height="'+img_height+'" width="'+img__wdth+'"/>'):pic_sent="","Nothing"==e[0].Nothing?(m_ele.prepend('<center style="color:#999; padding:20px;background:#fbfbfb; font-size:12px;">No Messages to show....</center>'),$("#this_counter_for_cr_id").html("Nothing")):e[i].username==user_logged?(""!=e[i].reply&&m_ele.prepend('<div class="msgc" style="margin-bottom: 30px;"> <div class="msg msgfrom">'+e[i].reply+'</div><div class="msgarr msgarrfrom"></div><div class="msgsentby msgsentbyfrom">'+e[i].username+"</div> </div>"),"Nothing"!=e[i].pics&&m_ele.prepend('<div class="msgc" style="margin-bottom: 30px;"><div class="msg msgfrom" style="padding:0px;background:transparent;">'+pic_sent+'</div><div class="msgarr msgarrfrom"></div><div class="msgsentby msgsentbyfrom">'+e[i].username+"</div> </div>")):(""!=e[i].reply&&m_ele.prepend('<div class="msgc"> <div class="msg">'+e[i].reply+'</div></div><div class="msgarr"></div><div class="msgsentby">'+e[i].username+"</div>"),"Nothing"!=e[i].pics&&m_ele.prepend('<div class="msgc"> <div class="msg" style="padding:0px;background:transparent;">'+pic_sent+'</div></div><div class="msgarr"></div><div class="msgsentby">'+e[i].username+"</div>"));msgarea=document.getElementById(m_ele.attr('id'));var t=msgarea.scrollHeight;if(t>lastScrollHeight){var s=t-lastScrollHeight;msgarea.scrollTop=s,lastScrollHeight=t}},"json")):$.post(url_vrt+"message/get_the_anonymous_activity_that_is_going_out_there",{cid:e},function(e){for(e.sort(function(e,i){return e.cr_id-i.cr_id}),$("#msg_data").html(""),$("#this_counter_for_cr_id").html(""),i=0;i<e.length;i++)"Nothing"!=e[i].pics?(pic_sent=url_vrt+"public/userdata/data_pics/"+e[i].pics,img.src=pic_sent,img_wdth=img.width,img_height=img.height,img_wdth>200?(img__wdth=200,img_height=img_height/img_wdth*img__wdth):img__wdth=img_wdth,pic_sent='<img src="'+url_vrt+"public/userdata/data_pics/"+e[i].pics+'" height="'+img_height+'" width="'+img__wdth+'"/>'):pic_sent="",$("#this_counter_for_cr_id").html(e[0].cr_id),e[i].username==user_logged?(""!=e[i].reply&&m_ele.append('<div class="msgc" style="margin-bottom: 30px;"> <div class="msg msgfrom">'+e[i].reply+'</div><div class="msgarr msgarrfrom"></div><div class="msgsentby msgsentbyfrom">'+e[i].username+"</div> </div>"),"Nothing"!=e[i].pics&&m_ele.append('<div class="msgc" style="margin-bottom: 30px;"><div class="msg msgfrom" style="padding:0px;background:transparent;">'+pic_sent+'</div><div class="msgarr msgarrfrom"></div><div class="msgsentby msgsentbyfrom">'+e[i].username+"</div> </div>")):(""!=e[i].reply&&m_ele.append('<div class="msgc"> <div class="msg">'+e[i].reply+'</div></div><div class="msgarr"></div><div class="msgsentby">'+e[i].username+"</div>"),"Nothing"!=e[i].pics&&m_ele.append('<div class="msgc"> <div class="msg" style="background:transparent;padding:0px;">'+pic_sent+'</div></div><div class="msgarr"></div><div class="msgsentby">'+e[i].username+"</div>"));msgarea=document.getElementById(m_ele.attr('id')),msgarea.scrollTop=msgarea.scrollHeight,lastScrollHeight=msgarea.scrollHeight},"json");}


window.smoothScroll = function(target) {
    var scrollContainer = target;
    do { //find scroll container
        scrollContainer = scrollContainer.parentNode;
        if (!scrollContainer) return;
        scrollContainer.scrollTop += 1;
    } while (scrollContainer.scrollTop == 0);

    var targetY = 0;
    do { //find the top of target relatively to the container
        if (target == scrollContainer) break;
        targetY += target.offsetTop;
    } while (target = target.offsetParent);

    scroll = function(c, a, b, i) {
        i++; if (i > 30) return;
        c.scrollTop = a + (b - a) / 30 * i;
        setTimeout(function(){ scroll(c, a, b, i); }, 20);
    }
    // start scrolling
    scroll(scrollContainer, scrollContainer.scrollTop, targetY, 0);
}


