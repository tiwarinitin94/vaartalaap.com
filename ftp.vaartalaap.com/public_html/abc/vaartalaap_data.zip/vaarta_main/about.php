<?php
class about extends Controller{
      
		  function __construct(){
		 
		    parent::__construct();
			
		 
		
}

function Index(){
		 $this->view->render('about/index');
		
}



}
?>