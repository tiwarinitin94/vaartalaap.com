<?php
class error Extends Controller{
function __construct(){
	parent::__construct();
	
}
function Index(){
		 $this->view->render('error/index');
}
}
?>