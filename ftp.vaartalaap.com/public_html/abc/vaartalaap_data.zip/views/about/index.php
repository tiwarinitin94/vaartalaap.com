
<div class="content"  >
<div id="wrapper" style="margin-top:100px;">
  <div class="row" style="background:#fff;border:.1px solid #efefef;">
  <div class="col-sm-4" style="padding:10px;">
   <ul class="nav nav-pills nav-stacked" style="position:fixed;margin:0px;"	>
  <li class="active" id="profile_set" onclick="smoothScroll(document.getElementById('set_content_about'))"><a href="?check=profile_set">About us</a></li>
 
  <li id="pswd_set"><a href="#" onclick="smoothScroll(document.getElementById('set_content_about2'))">Submit bug</a></li>
  <li id="pswd_set"><a href="#" onclick="smoothScroll(document.getElementById('set_content_about3'))">Bug finders</a></li>
  <li id="ac_set"><a href="#" onclick="smoothScroll(document.getElementById('set_content_about4'))">Feedback</a></li>
 
</ul>
  </div>
  <div class="col-sm-8" style="padding:10px;border-left:.1px solid #efefef;">

   <div class="panel panel-default">
   
  <div class="panel-heading" id="set_head">About us</div>
  
  <div class="panel-body" id="set_content_about">
 <!---------------------------------------------------------------About ------>
    Hello everyone, This is Nitin Tiwari from Vaartalaap. This is the site that I builded up for showing the creative side of my own initially. But now I would like to provide this power to each end everyone.
	We all make conversation with person that we see or we don't see, but with the help of social media, we can share everything with everyone. I believe that everyone has a creative side, which they can express
	by their face or voice or by writting it down. So I am working towards creating some tools that will help them to express. <br> 
	<br> 
	Soon there will be some amazing that you all will like, we have developed a game area, where games will bring other side of yours. Sometimes we ourselves unable to find the price of our talent. So all of these 
	will be there to help you all. The videos that we will accept will be moderate by our crew, if that video is not copied from other website, then we will publish it to our website. It will allow others to see your 
	real work and creativity. 
	<br><br>
	Playing games are my favorite thing when I get depressed. And whenever I score high in some tough games, I always feel nice and motivated. I feel that we all need some simple for understanding and tough for playing games. 
	These games also help us growing our senses. So we should play all those small games that help us to focus more. 
	<br>
	<br> 
	I am also expecting so many feedbacks from people. I would like to here from you all, which kind of games would like to see or videos you would like to share and stuff. You all can send me your feedback in feedback section. 
	
	
	    
  </div>

</div>
 <div id="set_content_about2"><div class="panel panel-default" id="set_content">
   
  <div class="panel-heading" id="set_head">Submit Bug</div>
  
  <div class="panel-body" >
  <!--------------------------------------------------------Bug Submit ------>
  This section is for student hackers. Students who are beginning hacking or those hobbyist hacker who would like to have their name in our hall of fame list, they can try security runs on our site, and they can submit their email, 
  name, and other details about them with the bug details. we will look at the bug, if you have submitted the right bug, we will show your name in our hall of fame. 
  <br>
  <br>
  <form id="bug_submit" method="post">
  <input type="text" placeholder="Name"required /><br><br>
  <input type="text" placeholder="Contact Details"required /><br><br>
  <input type="text" placeholder="Bug Name"/><br><br>
  <textarea type="text" placeholder="Bug Details" rows="4" style="border:.1px solid #555;"></textarea><br><br>
  <input type="submit"/><br>
  </form>
  </div>
  </div>

</div>
 <div id="set_content_about3"><div class="panel panel-default" id="set_content">
   
  <div class="panel-heading" id="set_head">Bug Finders</div>
  
  
  <div class="panel-body" >
  <!--------------------------------------------------------Bug Finders ------>
  <div style="background:#444; padding:3px;color:#fff;text-align:center;"> Acknowledgement</div>
  Vaarta team encourages the responsible disclosure of security vulnerabilities through the website security.
  <br>
  <br>
  Vaarta team would like to thank some people who actually find that security vulnerability.<br>
  To be eligible for this list, you must be the first person to responsibily disclose the issue and allow us a reasonable amount of time to address the issue before publishing the information.
  <br><br>
  <B>Security bug finders </b><br><br>
  <img src="<?php echo URL ?>public/images/ankit.jpg" style="border-radius:50%;height:100px;width:100px;"/>
  Ankit Singh <br><br>
  <a href="https://facebook.com/ankitk323" style="color:#888;">Facebook</a>
  <a href="https://twitter.com/ankitk323" style="color:#888;">Twitter</a>
  <a href="https://linkedin.com/in/ankitk323" style="color:#888;">Linked In</a>
  
 
  </div>
  </div>

</div>
<div class="panel panel-default">
   
  <div class="panel-heading" id="set_head">Feedback</div>
  
  
  <div class="panel-body" id="set_content_about4">
   <!--------------------------------------------------------Feedback ------>
 
  </div>

</div>
  
  </div>

</div>
 
</div>
 </div>

