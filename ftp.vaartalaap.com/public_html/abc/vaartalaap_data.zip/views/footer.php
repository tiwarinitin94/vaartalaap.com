<script>
function takeFeedback(){
	modal("<h1>Not developed area</h1>")
}
</script>
<div id="footer">
<div id="footer_copy_right">
    <a href="<?php echo URL;?>about">About</a> | <a href="<?php echo URL;?>gallery_area">Home</a> | <a href="feedback.php">Games</a> | <a href="#" onclick="takeFeedback()">Feedback</a> | <a href="<?php echo URL;?>privacy">Privacy</a> |<a href="feedback.php">Contact us</a> | <a href="http://ni3tiwari.blogspot.com" style="font-size:15px;">Nitin Tiwari</a> Production. (c) All rights reserved.
</div>
</div>
<!------------------
</body>
</html>