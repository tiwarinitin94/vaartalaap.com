<script>
/*function linkify(text){var rawText = strip(text); var urlRegex =/(\b(https?|ftp|file):\/\/[-A-Z0-9+&@#\/%?=~_|!:,.;]*[-A-Z0-9+&@#\/%=~_|])/ig; return rawText.replace(urlRegex, function(url) {if ( ( url.indexOf(".jpg") > 0 ) || ( url.indexOf(".png") > 0 ) || ( url.indexOf(".gif") > 0 )|| url.indexOf(".ico") > 0) {return '<img src="' + url + '">' + '<br/>' } else {return '<a href="' + url + '">' + url + '</a>' + '<br/>'  } }); }
function strip(html){ var tmp = document.createElement("DIV");tmp.innerHTML = html; var urlRegex =/(\b(https?|ftp|file):\/\/[-A-Z0-9+&@#\/%?=~_|!:,.;]*[-A-Z0-9+&@#\/%=~_|])/ig;return tmp.innerText.replace(urlRegex, function(url) { return '\n' + url });*/  
function linkify(text) { var urlRegex = /(((https?:\/\/)|(www\.))[^\s]+)/g; return text.replace(urlRegex, function(url,b,c) { var url2 = (c == 'www.') ?  'http://' +url : url;  return '<a href="' + url2 + '"  target="_blank">' + url + '</a>';   });}


$(document).ready(function(){
	
});
var c= document.createElement('canvas');
var check=0;
	   
function runUpload(){
	modal(""+
	"<form method='POST' enctype='multipart/form-data'>"+
	"<textarea id='post' onkeypress='createImage()' name='post' title='What u r upto' placeholder='Type here to create text image' style='width:100%;'></textarea> "+
	"<div id='showTheImage' style='width:100%;'></div>"+
	"</form>"+
	"");
	$('#post').expandable(); $('#post').keyup(function (e){ if(e.keyCode == 13){var curr = getCaret(this);var val = $(this).val();var end = val.length; $(this).val( val.substr(0, curr) + '<br>' + val.substr(curr, end));}});
	
	 
}

function createImage(){
	
	var text=$('#post').val();
	console.log(text);
	ctx = c.getContext("2d");
	  div = document.getElementById('showTheImage'); 
	if(check==1){
		console.log("canvas "+check);
		ctx.fillText(text,10,50);
	}else{
	console.log("no canvas ");
	   
        c.width  = $('#post').innerWidth;
        c.height =  $('#post').innerHeight;
		c.display='block';
        c.id="theTextImage"
      
		
		ctx.font = "30px Arial";
		ctx.fillText(text,10,50);
        
        c.style.border   = "1px solid";
        div.appendChild(c)
		check=1;
	}
}

 

</script>
<div class="content" > <div class="postForm1" > 
  <div id="poster" onclick="runUpload()">
  <div style="background-color:#fff;overflow:hidden; color:#888;clear:both;border:.1px solid #efefef;padding:10px;margin:100px 0px  auto; text-align:center;"> What are you going to create today?... <img src="<?php echo URL;?>public/images/camera.png" onclick="togglepost()"title="Upload image"style="cursor:pointer;height:30px; margin:0px auto;width:30px;"/></div>

  </div>
  
  <div id="message"></div>
  
   <div id="newsfeed_home_friends"></div></div></div>
  
  <div style="display:none;">
   <form rel="<?php echo URL;?>gallery_area/stick_it" id="stick_post" method="POST" enctype="multipart/form-data" >
      <center><img src="<?php echo URL;?>public/images/camera.png" onclick="togglepost()"title="Upload image"style="cursor:pointer;height:30px; width:30px;"/></center>
  <input type="file" id="file0" name="pic0" accept="image/*" style="display:none;background-color:transparent;"/><br>  <textarea id="post" name="post" title="What u r upto" placeholder="Shuru karo Vaartalaap.........." style="padding:5px;float:left;" ></textarea> 
	<input type="submit"  id="stick_it"  value="Stick it" style="margin-left:5px;float:left;height:40px;background-color:DCE5EE;  border:1px solid #fbfbfb;"/>
	 <div id="image_preview" style="padding:10px;display:none;float:left;clear both; overflow:hidden;"><!---for preview------> <div style='overflow:hidden;width:100px;height:80px;float:left;margin-left:10px;margin-top:5px;'><a href="#" onclick="call_click(0); return false;" value="url()" />
   <img id="previewing0" rel='0' class="new_img"src="<?php echo URL;?>public/images/noimage.png" /> </a></div> </div><div id="message"> </div><!----for showing error---->  
  </form>
  
  


 