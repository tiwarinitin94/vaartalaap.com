<div class="content">
<div id="error" ><label style="font-size:18px;color:rgba(10,110,210,1);">Thank you for Sign up, You are welcome to Vaarta</label> <br><br>Now please click on the link we have emailed to confirm the Login or <a href="<?php echo URL;?>Index">direct login</a> from here.
</div>

</div>