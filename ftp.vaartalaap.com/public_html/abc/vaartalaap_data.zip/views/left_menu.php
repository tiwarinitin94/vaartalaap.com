<?php

?>
<div style="width:100%;bottom:0px;position:fixed;background:#fafafa;z-index:4;-moz-box-shadow:0px 4px 4px rgba(90,90,90,.2), 0px -4px 4px rgba(90,90,90,.2);box-shadow:0px 4px 4px rgba(90,90,90,.2), 0px -4px 4px rgba(90,90,90,.2);">
<div style="width:100%; ">
<center>
<a href="<?php echo URL."message";?>" title="Message"> <img src="<?php echo URL;?>public/images/msg.png" style="width:50px;padding:10px; "/></a>
<a href="<?php echo URL."settings";?>" title="Settings"><img src="<?php echo URL;?>public/images/new_set.png" style="width:50px;padding:10px; "/></a>
<a href="<?php echo URL."news";?>" title="Notification"><img src="<?php echo URL;?>public/images/news.png" style="width:50px; padding:10px;"/></a>
<a href="<?php echo URL."requests";?>" title="Requests"><img src="<?php echo URL;?>public/images/frenz.png" style="width:50px;padding:10px; "/></a>
<a href="<?php echo URL."message";?>"><img src="<?php echo URL;?>public/images/msg.png" style="width:50px;padding:10px; "/></a>
</center>
</div>
</div>
