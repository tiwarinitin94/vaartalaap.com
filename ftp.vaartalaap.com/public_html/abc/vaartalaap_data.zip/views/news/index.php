
<div class="content">
<div class="head">
This is news
</div>
</div>