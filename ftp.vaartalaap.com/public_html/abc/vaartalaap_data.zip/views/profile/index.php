<?php 
    if(isset($this->data_profile)){
	 if($this->data_profile['profile_pic'] ==""){
				 $profile_=URL."public/images/default-pic.png";
				  }else{
					  $profile_=URL."public/userdata/profile_pics/".$this->data_profile['profile_pic'];
				  }	
				  
	}else{
		echo "<script>alert('Something went terribly wrong');</script>";
	  die();
	}
		
?><script>function fetch_for_profile(fetch){if(fetch=="all_friends"){	$(document).ready(function(){ $.post(url_vrt+'profile/friends_of_pro/',{profile_data:user.user_profile},function(o){	if(o!=""){ for(var i=0; i<o.length;i++){ if(i==15){ break; }else{ if(o[i]!=""){	modal('<div id="this_will_show_image"></div>'); profile_pic_check(o[i], "all","");	} }}}else{modal('<div id="error"><label style="color:#999;">Seems like you don\'t have friends. </label></div>');} },'json');});	
	}else{	$(document).ready(function(){$.post(url_vrt+'profile/image_data/',{data:'all',profile_data:user.user_profile},function(o){  if(o!=""){for(var i=0; i<o.length;i++){ modal('<div id="this_will_show_image_data"></div>'); check_file_pro(o[i].post_image,"all"); } }else{ $("#image_data").unbind().append('<div id="error"><label style="color:#999;">Seems like you don\'t have photos. </label></div>'); } },'json'); });}}var user={user_profile:"<?php echo $this->data_profile['username']; ?>",id:"<?php echo $this->data_profile['id']; ?>",profile_image:"<?php echo $profile_; ?>",firstName:"<?php echo $this->data_profile['first_name']; ?>",lastName:"<?php echo $this->data_profile['last_name']; ?>",bio:"<?php echo $this->data_profile['bio']; ?>",country:"<?php echo $this->data_profile['country']; ?>"};$(document).ready(function(){$('#vaarta').click(function(){if($('#vaarta_rel').height()){$('#vaarta_rel').css('height','0px');$('#vaarta_rel').css('padding','0px');}else{$('#vaarta_rel').css('height','auto');$('#vaarta_rel').css('padding','10px 0px');}});    $('#add_user').click(function(){ if($('#add_user').html()=="Pick User"){/*If send request*/send_request(user_pro);}else if($('#add_user').html()=="Unpick"){/*If cancel request*/console.log("Unpick the user");}});  
   $.post(url_vrt+'profile/check_follow_if/',{'u_id_check':user.user_profile,profile_data:user.user_profile},function(o){  if(o.trim()=="yes"){ $("#follow").html("Following");  
	   }else{  $("#follow").html("Follow");} }); $("#follow").mouseover(function() {if ($("#follow").html() == "Following") {	$("#follow").html("Unfollow");}if ($("#follow").html() == "Follow") {$("#follow").html("Follow User");}});
	 $("#follow").mouseout(function() {  if ($("#follow").html() == "Unfollow") { $("#follow").html("Following");}if ($("#follow").html() == "Follow User") {$("#follow").html("Follow");}});$('#follow').click(function(){  var text_c = $('#follow').html();if(text_c === "Follow User"){follow_user(user.user_profile);}else if(text_c === "Unfollow"){unfollow_user(user.user_profile);}  }); });function cancel(){$.post(url_vrt+'profile/cancel_request',{'data':user_pro},function(o){$('#add_user').html('Pick User'); $("#cr_cancel").remove();});}setTitle(""+user.firstName+"");
</script>
<div class="content">
<div id="wrapper" style="margin-top:90px; padding-bottom:10%;">
  <div class="row">
   <div class="col-sm-6">
   <div class="left_pro"style="max-width:600px;">
   <div id="pro_intro_pro">
   <img id='profile_img_pro'src='<?php echo URL;?>public/images/default-pic.png' title='"+firstName+"' style='float:left;border-radius:'50%'; width='50%'  />
   <div class='gal_name_pro' style='float:left; position:relative;max-width:180px;'>
   <br>
   <button id="vaarta">Start Vaarta <label style="margin-top:-10px; outline:none;float:right;padding:5px;">&#8964;</label></button>
   <div id="vaarta_rel"><button >Send Message</button><button id="follow">Follow</button><button id="add_user">Pick User</button></div>
   </div>
    
   </div><br>
   
   <div id='frenz'><button id="edit" onclick="fetch_for_profile('all_friends')">See All</button>
<label id='heading' >Frenz</label><br><br></div><div id='image_data'><button id="edit" onclick="fetch_for_profile('all_image')">See All</button><label id='heading' >Photos </label><br><br></div><div id='followers'><button id="edit" onclick="fetch_for_profile('all_image')">See All</button><label id='heading' >Followers</label><br><br></div></div>
</div>
 <div class="col-sm-6">
<div class="content3" style="max-width:600px;">
<div id="info_pro"></div><div id="info_pro_hobby"></div><div id="info_pro_style"></div><div id="info_pro_sign">
<div class='gal_name'style='float:none;font-size:13px;text-shadow:none;'><img id='sign_image'src='<?php echo URL;?>public/images/vaarta2.png' style="width:100%;"/></div>

</div></div></div>
</div>
</div>
</div>
<div style="display:none;">