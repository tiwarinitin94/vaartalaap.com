<?php 
  class Models{
	  public function __construct(){
		 $this->db= new database();
		 
	  }
	  
	 
  }
?>